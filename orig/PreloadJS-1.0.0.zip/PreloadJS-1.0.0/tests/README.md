## Setup and run tests ##
* Run via Grunt
    * Install dependencies; npm install;
    * Run tests in browser: grunt;
    * Run headless: grunt jasmine;
    
